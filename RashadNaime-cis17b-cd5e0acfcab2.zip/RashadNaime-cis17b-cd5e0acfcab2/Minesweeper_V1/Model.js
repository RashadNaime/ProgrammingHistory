/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//
//var Grid = {
//    
//    cell :{"value":"9" , "revealed": "false"},
//    
//    array = [10][10], 
//    for(var x = 0; x < 10 ; x++){
//        for(var y = 0; y < 10; y++){
//            arr[x][y] = cell;
//        }
//        
//    }
//   //var square = {value: "9", revealed: false}; 
//    
//};

    var cell = {"value":"9" , "revealed": "false"};
    
    var array = [10][10]; 
    for(var x = 0; x < 10 ; x++){
        for(var y = 0; y < 10; y++){
            array[x][y] = cell;
        }
        
    }

    
