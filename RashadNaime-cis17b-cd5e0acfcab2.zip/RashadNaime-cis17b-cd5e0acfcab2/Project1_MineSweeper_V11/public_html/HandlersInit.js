// init - called when the page has completed loading

window.onload = init;

function init() {
    //board.generateGrid();   //Generates bomb positions
    //board.inilGrid();       //Initializes spots regarding how many bombs touching
    board.fillTable();      //Assigns pictures, also used to output after a click
    
    
    //This outputs the board using text rather than pictures
    //board.outputGrid();
}