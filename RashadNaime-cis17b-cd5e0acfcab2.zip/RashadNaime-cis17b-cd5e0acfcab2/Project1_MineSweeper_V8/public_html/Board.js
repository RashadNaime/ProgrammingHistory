
var board = {
    boardSize: 10,      //Size of the board (10x10)
    numSquares: 85,     //Number of squares that aren't bombs
    firstClick: true,   //This makes sure that the first input will not cause a game over
    losegame: false,    //If player has clicked on a mine losegame flag is set to true
    //This is the array to hold all the values of the minesweeper table
    array:[             
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]],
        [["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false],["0",false,false]]],
    
    //This allows users to click on the board, the element is also called in the table
    fire: function(clicked_id,event) {
        //row and column pass the id of the table
        var row = clicked_id.charAt(0);
        var column = clicked_id.charAt(1);
        //This is the firstclick check, it generates the minesweeper table after the first click
        //prevents the user from getting a gameover click one
        if (this.firstClick===true){
            board.firstPick(row,column); //takes the first click
            board.generateGrid();        //generates grid after
            board.inilGrid();
            board.open(row,column);
            board.floodFill();
            board.fillTable();
            //board.outputGrid();
        }
        //This is what effects the grid after the first click
        else if (this.firstClick===false){
            if(event.button===0){
                
                if (this.array[row][column][2] === false){
                    if (this.array[row][column][1] === false){
                        this.array[row][column][1] = true;
                        board.gameCheck(); //gamecheck is to see if user has lost 
                        board.floodFill(); //floodfill is used to open multiple squares when a blank tile is selected
                        board.fillTable(); //fills the entire table
                        if(losegame === false){ //This is the flag check to see if user has lost
                        board.checkWin();
                        }
                    }
                    //This allows the user to open squares 
                    else if (this.array[row][column][1]===true){
                        board.open(row,column);
                        board.floodFill();
                        board.gameCheck();
                        board.fillTable();
                    if(losegame === false){
                        board.checkWin();
                        }
                    }
                    
                }

                //This uses the floodfill function if zero square is clicked
                if (this.array[row][column][0] === 0)
                    board.floodFill();
            }
            //This is the right click for flagging
            //It does not reveal the square but places a flag
            //If the tile is right clicked again it removes the flag
            else if (event.button===2){
                if(this.array[row][column][1] === false){

                    if(this.array[row][column][2]===true)
                        this.array[row][column][2] = false;

                    else if(this.array[row][column][2]===false)
                        this.array[row][column][2] = true;  
                }
        }
    }  
        board.fillTable();   
        this.firstClick = false;
    },
    
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
    generateGrid: function() {
        //Create and generate a set number of bombs for the size of the qrid
        var numBombs = 0;
        while(numBombs<15)
        {
            //randomize the bombs throughout the grid, again after the first click
            var i=Math.floor(Math.random() * 10);
            var j=Math.floor(Math.random() * 10); 
            //This checks to see if there is already a bomb in place, if not then place the bomb within the grid
            if(this.array[i][j][0] !== -1 && this.array[i][j][0] !== 9){
                numBombs++;
                this.array[i][j][0] = -1;
            }
        }
    },
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
    inilGrid: function(){
        for(var x = 0; x < 10; x++){
            for(var y = 0; y < 10; y++){
   
                if (this.array[x][y][0]!== -1){  //Only loops if point is not a bomb
                    var count = 0;          //Keeps track of number of bombs for each point
                    var startX = x-1;       //Starting point of 3x3 for x
  
                    for(var p = 0; p < 3; p++){
                        var startY = y-1;   //Starting point of 3x3 for y
                        for (var i = 0; i < 3; i++){

                            //Checks that the window is moving within the range of the grid
                            if (startX>=0 && startY>=0 && startX<10 && startY<10){
                                if (this.array[startX][startY][0]===-1){
                                    count++;
                                }
                            }                
                            startY++; //Moves to next column of 3x3
                        }
                    startX++;         //Moves to next row of 3x3
                    }
                    //End of calculating bombs for this specific point
                    this.array[x][y][0] = count; //Assigns point on grid to number of bombs found
                }
            }
        }
    },
////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////    
    //Output function with document.write, No longer useful tbh
    outputGrid: function(){
        for (var x = 0 ; x < 10; x++){
            for (var y = 0; y < 10; y++){
                document.write(this.array[x][y][0]);
                document.write("  ");
            }
            document.write("<br>");
        }
    },
////////////////////////////////////////////////////////////////    
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////    
    fillTable: function(){
        //create the entire 10 X 10 grid
        for(var x = 0; x < 10; x++){
            for (var y = 0; y < 10; y++){
                //set locations using x and y coordinates
                var location = x.toString() + y.toString();
                //set cells equal to the x and y position, which would be the square
                var cell = document.getElementById(location);
                
                // This sets attributes to each square, bombs being -1, 0 has floodfill
                if(this.array[x][y][1] === true)
                {
                    if (this.array[x][y][0] === 0)
                        cell.setAttribute("class", "zero");
                    else if (this.array[x][y][0] === -1)
                        cell.setAttribute("class", "bomb");
                    else if (this.array[x][y][0] === 1)
                        cell.setAttribute("class", "one");
                    else if (this.array[x][y][0] === 2)
                        cell.setAttribute("class", "two");
                    else if (this.array[x][y][0] === 3)
                        cell.setAttribute("class", "three");
                    else if (this.array[x][y][0] === 4)
                        cell.setAttribute("class", "four");
                    else if (this.array[x][y][0] === 5)
                        cell.setAttribute("class", "five");
                    else if (this.array[x][y][0] === 6)
                        cell.setAttribute("class", "six");
                    else if (this.array[x][y][0] === 7)
                        cell.setAttribute("class", "seven");
                    else if (this.array[x][y][0] === 8)
                        cell.setAttribute("class", "eight");
                }
                //This is false so it shows that square has not been clicked on
                else if (this.array[x][y][1] === false){
                    cell.setAttribute("class", "closed");
                }
                //This shows the a flag placed on a square
                if (this.array[x][y][2] === true){
                    cell.setAttribute("class", "flag");
                }
                
            }
        }
    },
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////   
    startOpen: function(x,y){
        if (x>=0 && y>=0 && x<10 && y<10)
            this.array[x][y][1] = true;
    },
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
    open: function(x,y){
        board.startOpen(x,y-1);
        board.startOpen(x,y*1+1);
        board.startOpen(x-1,y);
        board.startOpen(x-1,y-1);
        board.startOpen(x-1,y*1+1);
        board.startOpen(x*1+1,y-1);
        board.startOpen(x*1+1,y);
        board.startOpen(x*1+1,y*1+1);
    },
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
    floodFill: function(){
        //The floodfill function is used to open all 0 squares next to a 0 square that was clicked
        for(var t = 0; t < 100; t++){
            for(var x = 0; x < 10; x++){
                
                
                for(var y = 0; y < 10; y++){
                    if (this.array[x][y][0] === 0){
                        if (this.array[x][y][1] === true){
                            board.open(x,y); //opens all 0 squares
                        }
                    }
                }
                
                
            }
        }
    },
    //firstpick is used to make sure none of the squares on initial click are bombs 
    firstPick: function(x,y){
        board.noBomb(x,y);
        board.noBomb(x,y-1);
        board.noBomb(x,y*1+1);
        board.noBomb(x-1,y);
        board.noBomb(x-1,y-1);
        board.noBomb(x-1,y*1+1);
        board.noBomb(x*1+1,y);
        board.noBomb(x*1+1,y-1);
        board.noBomb(x*1+1,y*1+1);
    },
    //Nobomb does not allow any bombs to be placed on the initial grid
    noBomb: function(x,y){
        if (x>=0 && y>=0 && x<10 && y<10){
            this.array[x][y][0] = 9;
        }
    },
    //This function is used for the lose condition
    gameCheck: function(){
        //The flag clickbomb checks to see if any bombs have been selected
        var clickBomb = false;
        for (var x = 0; x < 10; x++){
            for (var y = 0; y < 10; y++){
                //If the tile has a bomb, and if it is revealed that sets the flag to true
                if (this.array[x][y][0]===-1 && this.array[x][y][1]===true &&this.array[x][y][2]===false)
                    clickBomb = true;
            }
        }
        //If clickbomb is set to true show losing message and reveal the rest of the board
        if (clickBomb === true){
            alert("You clicked on a bomb");
        for(x = 0; x < 10; x++){
            for(y=0; y <10; y++){
                this.array[x][y][1] = true; 
            }
        }
          board.fillTable();
          this.losegame = true; //set the losegame flag equal to true 
          
        }
 
    },
    checkWin: function(){
        //Counts the entire board, the win condition is if all tiles except for mines have been clicked
        var counter = 0;
        for (var x = 0; x < 10; x++){
            for (var y = 0; y < 10; y++){
                if (this.array[x][y][1]===true && this.array[x][y][0]!==-1)
                    counter++;
            }
        }
        if (counter==85)
            alert("You have won");
    }
};



