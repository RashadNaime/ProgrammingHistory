    //set value to start new game
    var game = new Game();
    var counter = 0; //set the counter to 0 so it can be alternated in function
    
    function play() {
        //call the board by id 
        var board = document.getElementById('board'); 
        //allows user to click square and add an x or o 
        board.addEventListener('click',(event)=>{
            event.target.innerHTML = game.players[counter].symbol;
            
            var squareNum = event.target.id.split('');
            var row = squareNum[0];
            var col = squareNum[1];
            
            //place symbol based on turn
            game.board.grid[row][col].Turn();
            //Game Board Check is not working, causing counter issues 
           // game.board.check_grid(); 
            
            if(counter == 0) {counter = 1}
            else {counter = 0}
            
        });
    }

    //places in the new game button and resets the grid 
    function play_again() {
      var newBoard = document.getElementById('new-game');
      newBoard.addEventListener('click', () => {
        for (let i = 0; i < 9; i++) {
          document.querySelectorAll('.square')[i].innerHTML = "";
        }
        game = new Game();
      });
    }

play();
play_again();
