/* 
    Created on : Sep 18, 2019, 6:28:09 PM
    Author     : Head First Javascript Example Project
 */


function print_tie() {
  console.log("It's a tie");
}