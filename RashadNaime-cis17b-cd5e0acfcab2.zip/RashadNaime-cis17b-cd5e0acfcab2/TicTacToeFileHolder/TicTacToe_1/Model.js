//This class constructs the blank square the grid will be on
class Square {
    constructor(state){
        this.state = "";
    }
    //This class will alternate the x's and the o's
    Turn() {
        if (counter == 0) {
          return this.state = "x";
        }
        else {
          return this.state = "o";
        }
  }
}
class Board { //construct board object
    constructor(grid) {
      this.grid = [ // make a 3 by 3 grid with squares to be filled
        [new Square(), new Square(), new Square()],
        [new Square(), new Square(), new Square()],
        [new Square(), new Square(), new Square()]
      ];
  }
  
    isFull (){ //Not looking for winner for now, just check if all spaces are filled
      
      var count = 0; //count through the grid and check if all blank spaces are filled
      for(var i = 0; i < 3; i++){
          for(var j = 0; j < 3; j++){
              if(this.grid[i][j].state != "")
                { count++}
          }
      }
      //if all are filled return true finish game
      if (count == 9){
          return true;
      }
      else { //else keep playing 
          return false; 
      }
  }

    check_grid() { //checking if the grid is full to print tie called from view.js
     if(this.isFull()){
         return this.printTie(); 
     }  
 }
}

class Player {
  constructor(symbol) {
    this.symbol = symbol;
  }
}

class Game {
  constructor() {
    this.board = new Board();
    this.players = [
      new Player("x"),
      new Player("o")
    ];
  }
}