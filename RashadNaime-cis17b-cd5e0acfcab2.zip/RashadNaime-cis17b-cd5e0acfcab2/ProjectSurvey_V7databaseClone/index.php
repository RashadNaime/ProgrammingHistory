
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Read Cookie from Javascript and Translate into PHP</title>
    </head>
    <body>
        <?php
            echo "Gotta Read the cookie </br>";
            $text=trim($_COOKIE["Questions"], '"');
            echo $text."</br>";
            $myObj = json_decode($text);
            echo '<pre>';
            //var_dump($myObj);
            
            //Take the object an convert it into an array
            $array = json_decode(json_encode($myObj), True);
            //print_r($array);
            echo "</br>";
            //Divide the array by each set of questions and answers
            $set1 = array_slice($array, 0, -3); //This selects the first array set
            //print_r($set1);
            //all questions and answers are seperated by sets, by splitting the array
              foreach($set1 as $item) { //Take every value in this set, an give it a variable to later be added to the database
              $n1s1 = $item[""];    
              $q1s1 =  $item['description'];
              $ans1s1 = $item['ans1'];
              $ans2s1 = $item['ans2'];
              $ans3s1 = $item['ans3'];
              $ans4s1 = $item['ans4'];
              $ans5s1 = $item['ans5'];
              }
            
            $set2 = array_slice($array, 1, -2);
            //print_r($set2);
            
              foreach($set2 as $item2) {
              $q1s2 =  $item2['description'];
              $ans1s2 = $item2['ans1'];
              $ans2s2 = $item2['ans2'];
              $ans3s2 = $item2['ans3'];
              $ans4s2 = $item2['ans4'];
              $ans5s2 = $item2['ans5'];
              }        
            
            $set3 = array_slice($array, 2, -1);
            //print_r($set3);
            
              foreach($set3 as $item3) {
              $q1s3 =  $item3['description'];
              $ans1s3 = $item3['ans1'];
              $ans2s3 = $item3['ans2'];
              $ans3s3 = $item3['ans3'];
              $ans4s3 = $item3['ans4'];
              $ans5s3 = $item3['ans5'];
              }
              
            $set4 = array_slice($array, 3);
            //print_r($set4);
            
              foreach($set4 as $item4) {
              $q1s4 =  $item4['description'];
              $ans1s4 = $item4['ans1'];
              $ans2s4 = $item4['ans2'];
              $ans3s4 = $item4['ans3'];
              $ans4s4 = $item4['ans4'];
              $ans5s4 = $item4['ans5'];
              }         

        //Connect to the database, and start entering in the data        
	//Straight out of W3Schools
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "survey";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	echo "Connected successfully";
        
        
                //Query the database
        $sql="SELECT `Survey-ID`, `surveyname`, `Question`, `answer1`, `answer2`,`answer3`,`answer4`,`answer5` FROM `rnaime_entity_survey`;";
        $result=$conn->query($sql);
        //$rs = mysqli_query($conn,$query);
        echo "<table border='1'>";
		    echo "<tr><th>".'Survey-ID'."</th>";
            echo "<th>".'SurveyName'."</th>";
            echo "<th>".'Question'."</th>";
            echo "<th>".'Answer1'."</th>";
            echo "<th>".'Answer2'."</th>";
            echo "<th>".'Answer3'."</th>";
            echo "<th>".'Answer4'."</th>";
            echo "<th>".'Answer5'."</th></tr>";
        while($re = $result->fetch_assoc()){
                  echo "<tr><td>".$re['Survey-ID']."</td>";
                  echo "<td>".$re['surveyname']."</td>";
                  echo "<td>".$re['Question']."</td>";
                  echo "<td>".$re['answer1']."</td>";
                  echo "<td>".$re['answer2']."</td>";
                  echo "<td>".$re['answer3']."</td>";
                  echo "<td>".$re['answer4']."</td>";
                  echo "<td>".$re['answer5']."</td></tr>";
        }
        echo "</table>";
                        
            //Every if statement is for a set of questions and answers
            if($n1s1 != null && $q1s1 != null && $ans1s1 != null && $ans2s1 != null){

            $query = "INSERT INTO `survey`.`rnaime_entity_survey` (`surveyname`, `Question`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`)"
                    . " VALUES ('$n1s1', '$q1s1', '$ans1s1', '$ans2s1', '$ans3s1', '$ans4s1', '$ans5s1');";

            if ($conn->query($query) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
              }
            }
            else{
                echo "oops please input a survey name, question, and at least 2 answers!";
            }
////////////////////////////////////////////////////////////////////////////////     
            //Second question set
            if($q1s2 != null && $ans1s2 != null && $ans2s2 != null){

            $query = "INSERT INTO `survey`.`rnaime_entity_survey` (`surveyname`, `Question`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`)"
                    . " VALUES ('$n1s1', '$q1s2', '$ans1s2', '$ans2s2', '$ans3s2', '$ans4s2', '$ans5s2');";

            if ($conn->query($query) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
              }
            }
            else{
                echo "oops please input a question and at least 2 answers!";
            }  
            
////////////////////////////////////////////////////////////////////////////////  
            //Third question set
            if($q1s3 != null && $ans1s3 != null && $ans2s3 != null){

            $query = "INSERT INTO `survey`.`rnaime_entity_survey` (`surveyname`, `Question`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`)"
                    . " VALUES ('$n1s1', '$q1s3', '$ans1s3', '$ans2s3', '$ans3s3', '$ans4s3', '$ans5s3');";

            if ($conn->query($query) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
              }
            }
            else{
                echo "oops please input a question and at least 2 answers!";
            }             
////////////////////////////////////////////////////////////////////////////////  
            //Fourth question set
            if($q1s4 != null && $ans1s4 != null && $ans2s4 != null){

            $query = "INSERT INTO `survey`.`rnaime_entity_survey` (`surveyname`, `Question`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`)"
                    . " VALUES ('$n1s1', '$q1s4', '$ans1s4', '$ans2s4', '$ans3s4', '$ans4s4', '$ans5s4');";

            if ($conn->query($query) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
              }
            }
            else{
                echo "oops please input a question and at least 2 answers!";
            }                 
            
            //This will display the database with all the updated question included
            echo "<br><br>";            
            $sql="SELECT `Survey-ID`, `surveyname`, `Question`, `answer1`, `answer2`,`answer3`,`answer4`,`answer5` FROM `rnaime_entity_survey`;";
            $result=$conn->query($sql);
            //$rs = mysqli_query($conn,$query);
            echo "<table border='1'>";
                        echo "<tr><th>".'Survey-ID'."</th>";
                echo "<th>".'SurveyName'."</th>";
                echo "<th>".'Question'."</th>";
                echo "<th>".'Answer1'."</th>";
                echo "<th>".'Answer2'."</th>";
                echo "<th>".'Answer3'."</th>";
                echo "<th>".'Answer4'."</th>";
                echo "<th>".'Answer5'."</th></tr>";
            while($re = $result->fetch_assoc()){
                      echo "<tr><td>".$re['Survey-ID']."</td>";
                      echo "<td>".$re['surveyname']."</td>";
                      echo "<td>".$re['Question']."</td>";
                      echo "<td>".$re['answer1']."</td>";
                      echo "<td>".$re['answer2']."</td>";
                      echo "<td>".$re['answer3']."</td>";
                      echo "<td>".$re['answer4']."</td>";
                      echo "<td>".$re['answer5']."</td></tr>";
            }
            echo "</table>";
        ?>
    </body>
</html>