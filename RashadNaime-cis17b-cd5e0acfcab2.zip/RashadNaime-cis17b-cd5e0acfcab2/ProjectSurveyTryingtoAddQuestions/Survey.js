/*
 * Author:      Dr. Mark E. Lehr
 * Purpose:     Survey class
 */
//Constructor for the Survey
function Survey(name,description,quesNum){

    //How many arguments are provided
    var nArgs=arguments.length;//The number of arguments passed to the function
    if(nArgs==0||nArgs>3){//Empty Question
        this.name="";
        this.description="";
    }else if(nArgs==3){//Question provided with all inputs
        this.name=name;
        this.description=description;
        this.quesNum= quesNum;
    }else if(nArgs==2){//Question provided with no answers added latter
        this.name=name;
        this.description=description;
    }else{
        this.name=name.name;
        this.description=name.description;
        this.quesNum=name.quesNum;
    }
};

//Setting the Category
Survey.prototype.setName=function(name){
    this.name=name;
};
//Setting the Question
Survey.prototype.setDesc=function(description){
    this.description=description;
};
//Adding an Answer
Survey.prototype.addQuesNum=function(quesNum){
    this.quesNum.push(quesNum);
};
//Accessing the Category
Survey.prototype.getName=function(){
    return this.name;
};
//Accessing the Question
Survey.prototype.getDesc=function(){
    return this.description;
};
//Accessing one of the Answers
Survey.prototype.getQuesNum=function(number){
    if(number>=0&&number<this.quesNum.length){
        return this.quesNum[number];
    }else{
        return "This is not a Question";
    }
};
//Displaying the Question
Survey.prototype.display=function(){
    document.write("<h2>"+this.description+"</h2>");
    for(var i=0;i<this.quesNum.length;i++){
        if(this.quesNum[i].length>0)
        document.write('<input type="checkbox" name='+this.name+" value="+this.quesNum+
                        ">"+this.quesNum[i]+"<br> </br>");
    }
};