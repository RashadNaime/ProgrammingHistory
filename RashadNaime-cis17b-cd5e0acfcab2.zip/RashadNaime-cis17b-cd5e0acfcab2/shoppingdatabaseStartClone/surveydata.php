<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
	//Straight out of W3Schools
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "survey";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	echo "Connected successfully";
        
        
                //Query the database
        $sql="SELECT `Survey-ID`, `surveyname`, `Question`, `answer1`, `answer2`,`answer3`,`answer4`,`answer5` FROM `rnaime_entity_survey`;";
        $result=$conn->query($sql);
        //$rs = mysqli_query($conn,$query);
        echo "<table border='1'>";
		    echo "<tr><th>".'Survey-ID'."</th>";
            echo "<th>".'SurveyName'."</th>";
            echo "<th>".'Question'."</th>";
            echo "<th>".'Answer1'."</th>";
            echo "<th>".'Answer2'."</th>";
            echo "<th>".'Answer3'."</th>";
            echo "<th>".'Answer4'."</th>";
            echo "<th>".'Answer5'."</th></tr>";
        while($re = $result->fetch_assoc()){
                  echo "<tr><td>".$re['Survey-ID']."</td>";
                  echo "<td>".$re['surveyname']."</td>";
                  echo "<td>".$re['Question']."</td>";
                  echo "<td>".$re['answer1']."</td>";
                  echo "<td>".$re['answer2']."</td>";
                  echo "<td>".$re['answer3']."</td>";
                  echo "<td>".$re['answer4']."</td>";
                  echo "<td>".$re['answer5']."</td></tr>";
        }
        echo "</table>";
        
        
                echo <<<END
        <form action="surveydata.php" method="post"><pre>
            SurveyName: <input type="text" name="surveyname">
            Question: <input type="text" name="question">
            Answer1: <input type="text" name="ans1">
            Answer2: <input type="text" name="ans2">
            Answer3: <input type="text" name="ans3">
            Answer4: <input type="text" name="ans4">
            Answer5: <input type="text" name="ans5">
            <input type="submit" value="ADD RECORD">
        </pre></form>
END;
        
            //Escape user inputs for security
            $n1s1 = mysqli_real_escape_string($conn, $_REQUEST['surveyname']);
            $q1s1 = mysqli_real_escape_string($conn, $_REQUEST['question']);
            $ans1s1 = mysqli_real_escape_string($conn, $_REQUEST['ans1']);
            $ans2s1 = mysqli_real_escape_string($conn, $_REQUEST['ans2']);
            $ans3s1 = mysqli_real_escape_string($conn, $_REQUEST['ans3']);
            $ans4s1 = mysqli_real_escape_string($conn, $_REQUEST['ans4']);
            $ans5s1 = mysqli_real_escape_string($conn, $_REQUEST['ans5']);
            
            if($n1s1 != null && $q1s1 != null && $ans1s1 != null && $ans2s1 != null){

            $query = "INSERT INTO `survey`.`rnaime_entity_survey` (`surveyname`, `Question`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`)"
                    . " VALUES ('$n1s1', '$q1s1', '$ans1s1', '$ans2s1', '$ans3s1', '$ans4s1', '$ans5s1');";

            if ($conn->query($query) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
              }
            }
            else{
                echo "oops please input all the information!";
            }
            echo "<br><br>";
// 
            
        $sql="SELECT `Survey-ID`, `surveyname`, `Question`, `answer1`, `answer2`,`answer3`,`answer4`,`answer5` FROM `rnaime_entity_survey`;";
        $result=$conn->query($sql);
        //$rs = mysqli_query($conn,$query);
        echo "<table border='1'>";
		    echo "<tr><th>".'Survey-ID'."</th>";
            echo "<th>".'SurveyName'."</th>";
            echo "<th>".'Question'."</th>";
            echo "<th>".'Answer1'."</th>";
            echo "<th>".'Answer2'."</th>";
            echo "<th>".'Answer3'."</th>";
            echo "<th>".'Answer4'."</th>";
            echo "<th>".'Answer5'."</th></tr>";
        while($re = $result->fetch_assoc()){
                  echo "<tr><td>".$re['Survey-ID']."</td>";
                  echo "<td>".$re['surveyname']."</td>";
                  echo "<td>".$re['Question']."</td>";
                  echo "<td>".$re['answer1']."</td>";
                  echo "<td>".$re['answer2']."</td>";
                  echo "<td>".$re['answer3']."</td>";
                  echo "<td>".$re['answer4']."</td>";
                  echo "<td>".$re['answer5']."</td></tr>";
        }
        echo "</table>";        
            

            
        //$result=$conn->query($query);
        ?>
    </body>
</html>
