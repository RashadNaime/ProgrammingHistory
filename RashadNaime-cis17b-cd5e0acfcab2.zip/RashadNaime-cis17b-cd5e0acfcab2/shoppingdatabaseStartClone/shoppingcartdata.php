<?php
	//Dr. Mark E. Lehr
	//Straight out of W3Schools
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "shopping";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	echo "Connected successfully";
        
        
                //Query the database
        $sql="SELECT `Shopping-ID`, `itemName`, `itemPrice`, `Quantity`, `totalprice`, `ConsumerName` FROM `rnaime_entity_shoppingcart`;";
        $result=$conn->query($sql);
        //$rs = mysqli_query($conn,$query);
        echo "<table border='1'>";
		    echo "<tr><th>".'Item Name'."</th>";
            echo "<th>".'Item Price'."</th>";
            echo "<th>".'Quantity'."</th>";
            echo "<th>".'Item Total'."</th>";
            echo "<th>".'Consumer'."</th></tr>";
        while($re = $result->fetch_assoc()){
                  echo "<tr><td>".$re['itemName']."</td>";
                  echo "<td>".$re['itemPrice']."</td>";
                  echo "<td>".$re['Quantity']."</td>";
                  echo "<td>".$re['totalprice']."</td>";
                  echo "<td>".$re['ConsumerName']."</td></tr>";
        }
        echo "</table>";
        
        
                echo <<<END
        <form action="shoppingcartdata.php" method="post"><pre>
            ItemName: <input type="text" name="itemname">
            ItemPrice: <input type="text" name="itemprice">
            Quantity: <input type="text" name="quantity">
            TotalPrice: <input type="text" name="totprice">
            ConsumerName: <input type="text" name="consumer">
            <input type="submit" value="ADD RECORD">
        </pre></form>
END;
        
            //Escape user inputs for security
            $ItemName = mysqli_real_escape_string($conn, $_REQUEST['itemname']);
            $ItemPrice = mysqli_real_escape_string($conn, $_REQUEST['itemprice']);
            $Quantity = mysqli_real_escape_string($conn, $_REQUEST['quantity']);
            $TotalPrice = mysqli_real_escape_string($conn, $_REQUEST['totprice']);
            $ConsName = mysqli_real_escape_string($conn, $_REQUEST['consumer']);
            
            if($ItemName != null && $ItemPrice != null && $Quantity != null && $TotalPrice != null && $ConsName != null){

            $query = "INSERT INTO `shopping`.`rnaime_entity_shoppingcart` (`itemName`, `itemPrice`, `Quantity`, `totalprice`, `ConsumerName`)"
                    . " VALUES ('$ItemName', '$ItemPrice', '$Quantity', '$TotalPrice', '$ConsName');";

            if ($conn->query($query) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
              }
            }
            else{
                echo "oops please input all the information!";
            }
            echo "<br><br>";
//            $selectquery="SELECT Shopping-ID FROM rnaime_entity_shoppingcart ORDER BY Shopping-ID DESC LIMIT 1";
//            $result2 = $mysqli->query($selectquery);
//            $row = $result2->fetch_assoc();
//            echo $row[`Shopping-ID`];
            

            
        //$result=$conn->query($query);
        ?>