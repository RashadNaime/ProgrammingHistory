/* 
 * File:   main.cpp
 * Author: James Rungsawang
 * Created on February 11th, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
#include <string>
#include <cstring>
#include <stdio.h>      /* printf, scanf, puts, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
// using std::tostring 
#include <bits/stdc++.h> 
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const int N = 10;   //Size of board (10 by 10)
const int M = 3;    //Size of window/range (3 by 3)
//Function Prototypes

void noBomb(int [10][10],int,int); //Ensures the first point and its 3x3 aren't bombs
void startOpen(int[10][10], string[10][10],int,int); //Opens one cell
void floodFill(int[10][10], string[10][10],int,int); //Fills all neighboring blanks
void open3x3(int[10][10], string[10][10],int,int);   //Uses startOpen to open 3x3
bool numClear(int[10][10], string [10][10],int,int);
bool clearOne(int[10][10], string [10][10],int,int);
void printTable(string[10][10]);
void printGrid(int [10][10]);
bool gameCheck(string [10][10],bool);

//Execution Begins Here!
int main(int argc, char** argv) {
 
    int array[N][N];    //The grid with real values
    string table[N][N]; //Table displayed to the player

    
    //Sets every value in grid to 0///////////////////////////////
    for(int x = 0; x < N; x++){     
        for(int y = 0; y < N; y++){
            array[x][y] = 0;
        }  
    }
    //////////////////////////////////////////////////////////////
    
    int numBombs=0; //Counter for the number of bombs generated
    srand(time(NULL)); //For rand function

    int firstx; //Used to move positions within 3x3 for x
    int firsty; //Used to move positions within 3x3 for y
    
    cout<<"========================================================="<<endl;
    cout<<"WELCOME TO MINESWEEPER!!"<<endl;
    cout<<"========================================================="<<endl<<endl;
    cout<<"Enter the first square to open!"<<endl;
    cout<<"(rows first and then the columns)"<<endl;
    
    cin>>firstx>>firsty;
    while (firstx<0 or firstx>9 or firsty<0 or firsty>9){
        cout<<"Invalid inputs, enter (0-9)"<<endl;
        cin>>firstx>>firsty;
    }
    
    //Guarantees for each point in a 3x3 around the first point cannot// 
    //be a bomb/////////////////////////////////////////////////////////
    noBomb(array,firstx,firsty);
    noBomb(array,firstx,firsty-1);
    noBomb(array,firstx,firsty+1);
    noBomb(array,firstx-1,firsty);
    noBomb(array,firstx-1,firsty-1);
    noBomb(array,firstx-1,firsty+1);
    noBomb(array,firstx+1,firsty);
    noBomb(array,firstx+1,firsty-1);
    noBomb(array,firstx+1,firsty+1);
   ////////////////////////////////////////////////////////////////////
    
    
    //Loops until there is a certain amount of bombs on the grid
    while(numBombs<15)
    {
        int i=rand()%10;
        int j=rand()%10;
        
        if(array[i][j]==0 and array[i][j]!=9){
            array[i][j]=-1; //Sets bombs to value of -1
            numBombs++;
        }
    }
        
        
    //////////////////////////////////////////////////////////////////////////////    
    //////////////////////////////////////////////////////////////////////////////   
    //////////////////////////////////////////////////////////////////////////////    
    for(int x = 0; x < N; x++){
        for(int y = 0; y < N; y++){
   
            if (array[x][y]!= -1){  //Only loops if point is not a bomb
            int count = 0;          //Keeps track of number of bombs for each point
            int startX = x-1;       //Starting point of 3x3 for x
  
            for(int p = 0; p < M; p++){
                int startY = y-1;   //Starting point of 3x3 for y
                for (int i = 0; i < M; i++){
                    
                    //Checks that the window is moving within the range of the grid
                    if (startX>=0 and startY>=0 and startX<N and startY<N){
                        if (array[startX][startY]==-1){
                            count++;
                        }
                    }                
                    startY++; //Moves to next column of 3x3
                }
            startX++;         //Moves to next row of 3x3
            }
            //End of calculating bombs for this specific point
            
            array[x][y] = count; //Assigns point on grid to number of bombs found
        }
        }
        
    }
    //////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    
    
    //Sets every value of table to ?
    for(int x = 0; x < N; x++){     
        for(int y = 0; y < N; y++){
            table[x][y] = '?';
        }  
    }
    
    
    //Opens the first point of grid onto the table
    table[firstx][firsty] = to_string(array[firstx][firsty]);
    //Opens the 3x3 grind around the first point
    open3x3(array,table,firstx,firsty);
    
    //Floodfill function ensures every 0 is bordered by a number
    floodFill(array,table,firstx,firsty);

    
    printGrid(array);
    printTable(table);
 
    
    bool winGame = false;   //Checking condition if game is won
    
    
    //THE ACTUAL START OF THE GAME
    string choice1;
    string choice2;
    int pickX;
    int pickY;
    
    while (winGame == false){
        cout<<"Enter a cell to open"<<endl;
        cout<<"(rows first then columns)"<<endl;
        cin>>choice1;
        if (choice1!="f"){
            cin>>choice2;
            pickX = atoi(choice1.c_str());
            pickY = atoi(choice2.c_str());
            while (pickX<0 or pickX>9 or pickY<0 or pickY>9){
                cout<<"Invalid inputs, enter (0-9)"<<endl;
                cin>>choice1>>choice2;
                pickX = atoi(choice1.c_str());
                pickY = atoi(choice2.c_str());
    }
            if(table[pickX][pickY] == "?"){
                if (array[pickX][pickY]==-1){
                    cout<<"============================="<<endl;
                    cout<<"YOU CLICKED ON A BOMB!!"<<endl;
                    cout<<"============================="<<endl;
                    return 0;
                }

                else{
                    table[pickX][pickY] = to_string(array[pickX][pickY]);
                    floodFill(array,table,pickX,pickY);
                    printTable(table);
                    cout<<endl<<"========================================================="<<endl;
                }
            }
            else{
                bool failed = false;
                failed = numClear(array,table,pickX,pickY);
                if (failed == false){
                    floodFill(array,table,firstx,firsty);
                    printTable(table);
                    cout<<endl<<"========================================================="<<endl;
                }
                else if (failed==true){
                    cout<<"============================="<<endl;
                    cout<<"THAT CELL WAS NOT FLAGGED PROPERLY"<<endl;
                    cout<<"YOU REVEALED A BOMB!!"<<endl;
                    cout<<"============================="<<endl;
                    return 0;
                }
                    
            }
        }
        
        if (choice1=="f"){
            cout<<"Enter the coordinates that you would like to flag"<<endl;
            cout<<"(rows first and then columns"<<endl;
            cin>>pickX;
            cin>>pickY;
            
            if (table[pickX][pickY]=="?")
                table[pickX][pickY] = "F";
            
            else if (table[pickX][pickY]=="F")
                table[pickX][pickY] = "?";
            
            else 
                cout<<endl<<"That cell is already open, you cannot flag it"<<endl<<endl;
 
            
            printTable(table);
        }   cout<<endl<<"========================================================="<<endl;
        winGame = gameCheck(table,winGame);
        
    }
    
    cout<<"You have won!"<<endl;
    
    return 0;
}

//Makes the first point and its 3x3 not bombs
void noBomb(int array[10][10],int firstx,int firsty){
    if (firstx>=0 and firsty>=0 and firstx<10 and firsty<10)
        array[firstx][firsty] = 9;
}

//Actually opens the first point on the table via function noBomb
void startOpen(int array[10][10], string table[10][10],int x,int y){
    if (x>=0 and y>=0 and x<10 and y<10){
            table[x][y] = to_string(array[x][y]);
    }
}

//Opens a 3x3 space around a given point on the table
void open3x3(int array[10][10], string table[10][10],int firstx,int firsty){
    startOpen(array,table,firstx,firsty-1);
    startOpen(array,table,firstx,firsty+1);
    startOpen(array,table,firstx-1,firsty);
    startOpen(array,table,firstx-1,firsty-1);
    startOpen(array,table,firstx-1,firsty+1);
    startOpen(array,table,firstx+1,firsty-1);
    startOpen(array,table,firstx+1,firsty);
    startOpen(array,table,firstx+1,firsty+1);
}

//This function makes sure that any zero clears bordering zeros
void floodFill(int array[10][10], string table[10][10],int x, int y) {
    
    for(int t = 0; t < 100; t++){
        for(int x = 0; x < 10; x++){
            for(int y = 0; y < 10; y++){
                if (table[x][y] == "0")
                    open3x3(array,table,x,y);
            }
        }
    }
}

//Simply prints the table for player
void printTable(string table[10][10]){
    int line = 0;
    cout<<"     0  1  2  3  4  5  6  7  8  9"<<endl;
    cout<<"    _____________________________"<<endl;
    for(int x = 0; x < N; x++){
        cout<<line<<"  |";
        line++;
        for(int y = 0; y < N; y++){
            cout<<setw(2)<<table[x][y]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<endl;
}

void printGrid(int array[10][10]){
    int line = 0; //Simply says what row you're on
    cout<<"      0   1   2   3   4   5   6   7   8   9"<<endl;
    cout<<"    _______________________________________"<<endl;
    for(int x = 0; x < N; x++){
        cout<<line<<"  |";
        line++;
        for(int y = 0; y < N; y++){
            cout<<setw(3)<<array[x][y]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<endl;
}

bool gameCheck(string table[10][10], bool winGame){
    int score = 0;
    for(int x = 0; x < 10; x++){
        for(int y = 0; y < 10; y++){
            if (table[x][y]!="F" and table[x][y]!="?"){
                score++;
            }
        }
    }
    //cout<<"Your score is "<<score<<endl;
    if (score == 85)
        return true;
    
    else return false;
}
bool numClear(int array[10][10], string table[10][10], int x, int y){
    bool openBomb = false;
    openBomb = clearOne(array,table,x,y-1);
    
    if (openBomb == false)
        openBomb = clearOne(array,table,x,y+1);
    if (openBomb == false)
        openBomb = clearOne(array,table,x-1,y);
    if (openBomb == false)
        openBomb = clearOne(array,table,x-1,y-1);
    if (openBomb == false)
        openBomb = clearOne(array,table,x-1,y+1);
    if (openBomb == false)
        openBomb = clearOne(array,table,x+1,y-1);
    if (openBomb == false)
        openBomb = clearOne(array,table,x+1,y);
    if (openBomb == false)
        openBomb = clearOne(array,table,x+1,y+1);
    
    return openBomb;
}

bool clearOne(int array[10][10], string table[10][10],int x, int y){
    if (table[x][y] == "?"){
        if (x>=0 and y>=0 and x<10 and y<10){
            table[x][y] = to_string(array[x][y]);
            
            if (array[x][y] == -1)
                return true;
            else
                return false;
        }
    }
    return false;
}