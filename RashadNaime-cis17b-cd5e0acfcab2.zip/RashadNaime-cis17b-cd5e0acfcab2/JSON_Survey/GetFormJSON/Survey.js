/*
 * Author:      Dr. Mark E. Lehr
 * Purpose:     Survey class
 */

//Constructor for the Survey
function Survey(name,description,quesNum){
    //Create an array with 2 objects
    var Question1={"name":"Favorite color?","ans1":"red","ans2":"blue","ans3":"green"};
    var Question2={"name":"Favorite car?","ans1":"honda","ans2":"mazda","ans3":"mitsubishi"};
    var Question=[];
    Question[0]=Question1;
    Question[1]=Question2;
    //Display the array
    for(var items=0;items<inventory.length;items++){
        document.write("The "+items+" Object</br>");
        var obj=inventory[items];
        for(var property in obj){
        document.write(property+"="+obj[property]+"</br>");
            }
          }
};
////Setting the Name
//Survey.prototype.setName=function(name){
//    this.name=name;
//};
////Setting the description
//Survey.prototype.setDesc=function(description){
//    this.description=description;
//};
////Set Question Number
//Survey.prototype.setquesNum=function(quesNum){
//    this.quesNum=quesNum;
//};
////Accessing the Name
//Survey.prototype.getName=function(){
//    return this.name;
//};
////Accessing the Description
//Survey.prototype.getDesc=function(){
//    return this.description;
//};
////Accessing the Question number
//Survey.prototype.getquesNum=function(){
//    return this.quesNum;
//};